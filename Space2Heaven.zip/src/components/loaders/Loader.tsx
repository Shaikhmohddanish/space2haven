const Loader = () => {
    return (
        <div className="w-10 h-10 loader-common-styles"></div>
    )
}
export default Loader