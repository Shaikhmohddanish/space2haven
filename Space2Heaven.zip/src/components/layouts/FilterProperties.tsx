"use client";

import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { filterTypes } from "@/constants";

const FilterProperties = ({
  setFilters,
  filters,
  setOpen,
}: { setFilters: Function; filters: any; setOpen: (open: boolean) => void }) => {
  const { toast } = useToast();
  const [localFilters, setLocalFilters] = useState(filters);

  const handleInputChange = (e: { target: { checked: any; name: any; value: any; type: any } }) => {
    const { name, value, type } = e.target;

    if (type === "checkbox") {
      const target = e.target;
      const checked = target.checked;

      setLocalFilters((prev: { [x: string]: never[] }) => {
        const prevArray = prev[name] || [];
        const updatedArray = checked
          ? [...prevArray, value]
          : prevArray.filter((item: any) => item !== value);

        return { ...prev, [name]: updatedArray };
      });
    } else if (name.includes("budget")) {
      const budgetKey = name.split(".")[1]; // "min" or "max"
      setLocalFilters((prev: { budget: any }) => ({
        ...prev,
        budget: { ...prev.budget, [budgetKey]: value },
      }));
    } else {
      setLocalFilters((prev: any) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  // ✅ Apply filters and close modal IMMEDIATELY
  const applyFiltersHandler = () => {
    setFilters(localFilters);
    toast({ description: "Filters applied!" });

    // 🟢 Ensures modal closes immediately
    if (typeof setOpen === "function") {
      setOpen(false);
    }
  };

  // ✅ Clear filters and close modal IMMEDIATELY
  const clearFiltersHandler = () => {
    const resetFilters = {
      bhk: "",
      budget: { min: "", max: "" },
      propertyType: [],
    };

    setLocalFilters(resetFilters);
    setFilters(resetFilters);
    toast({ description: "Filters cleared!" });

    // 🟢 Ensures modal closes immediately
    if (typeof setOpen === "function") {
      setOpen(false);
    }
  };

  return (
    <div className="p-6 bg-white shadow-lg rounded-lg w-full max-w-3xl text-sm flex flex-col gap-4">
      <h2 className="font-semibold text-center text-gray-700 text-lg">Personalize your space here...</h2>

      {/* BHK Selection */}
      <div className="mb-4">
        <p className="mb-2 font-medium text-gray-600">Configuration (BHK)</p>
        <div className="flex gap-2">
          {["1 BHK", "2 BHK", "3 BHK", "4+ BHK"].map((option) => (
            <button
              key={option}
              name="bhk"
              onClick={() =>
                setLocalFilters((prev: any) => ({
                  ...prev,
                  bhk: option,
                }))
              }
              className={`px-4 py-2 rounded-full border ${
                localFilters.bhk === option ? "bg-home text-white" : "bg-gray-200 text-home"
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Budget Filter */}
      <div className="mb-4">
        <p className="mb-2 font-medium text-gray-600">Budget</p>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            name="budget.min"
            placeholder="Min Budget"
            value={localFilters.budget?.min || ""}
            onChange={handleInputChange}
            className="p-3 border rounded-md focus:ring focus:outline-none w-full"
          />
          <input
            type="number"
            name="budget.max"
            placeholder="Max Budget"
            value={localFilters.budget?.max || ""}
            onChange={handleInputChange}
            className="p-3 border rounded-md focus:ring focus:outline-none w-full"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <button
          onClick={clearFiltersHandler}
          className="w-1/2 bg-gray-500 hover:bg-gray-400 text-white py-2 rounded-md transition"
        >
          Clear Filters
        </button>
        <button
          onClick={applyFiltersHandler}
          className="w-1/2 bg-gray-900 hover:bg-gray-700 text-white py-2 rounded-md transition"
        >
          Apply Filters
        </button>
      </div>
    </div>
  );
};

export default FilterProperties;
