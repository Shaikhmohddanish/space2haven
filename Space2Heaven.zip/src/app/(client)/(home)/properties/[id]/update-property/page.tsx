const updateProperty = () => {
  return (
    <div>updateProperty</div>
  )
}
export default updateProperty