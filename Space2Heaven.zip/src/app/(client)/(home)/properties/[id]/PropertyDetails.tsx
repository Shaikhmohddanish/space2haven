"use client";

import React from "react";
import { DisplayCarousel, DialogBox, DynamicCarousel } from "@/components";
import { Check, Trash2, UserRoundPen } from "lucide-react";
import moment from "moment";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

interface Property {
  _id: string;
  title: string;
  images: string[];
  price: string;
  propertyType: string;
  configuration: string;
  description: string;
  location: string;
  area: string;
  yearBuilt: number;
  features: string[];
  address: {
    city: string;
    state: string;
  };
  updatedAt: string;
}

interface PropertyDetailsProps {
  property: Property;
  recommended: Property[];
  isAdmin?: boolean; // Admin check for edit/delete
}

const PropertyDetails: React.FC<PropertyDetailsProps> = ({ property, recommended, isAdmin = false }) => {
  const router = useRouter();
  const { toast } = useToast();

  if (!property) {
    return <div className="text-center py-20 text-xl font-semibold">Property details not found.</div>;
  }

  const {
    _id,
    images,
    title,
    configuration,
    area,
    features,
    location,
    description,
    price,
    address,
    updatedAt,
  } = property;

  // 🔥 Delete Property Function
  const deleteProperty = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`/api/admin/delete-property/${_id}`, { method: "DELETE" });

      if (!response.ok) throw new Error("Error deleting property");

      toast({ description: "Property deleted successfully" });
      router.push("/properties"); // Redirect to properties list
    } catch (error) {
      console.error("Error deleting property:", error);
      toast({ description: "Something went wrong! Unable to delete" });
    }
  };

  return (
    <section className="min-h-screen w-full flex-center flex-col py-20 px-4 bg-[url('/images/pattern.png')]">
      {/* 🏡 Property Image Carousel */}
      <div className="w-full max-w-6xl mb-10">
        {images && images.length > 0 && <DisplayCarousel images={images} />}
      </div>

      {/* 📜 Property Details */}
      <div className="w-full max-w-6xl space-y-6 bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-center w-full">
          <h1 className="text-xl lg:text-3xl font-bold text-left w-full text-home">{title || "Title"}</h1>

          {/* 🔧 Admin Controls */}
          {isAdmin && (
            <div className="flex-center gap-2">
              <Link href={`/properties/${_id}/update-property`}>
                <UserRoundPen size={20} color="green" />
              </Link>
              <Trash2 size={20} color="red" onClick={deleteProperty} className="cursor-pointer" />
            </div>
          )}
        </div>

        {/* 🔹 Basic Info */}
        <div className="flex items-center justify-between">
          <h2 className="md:text-lg font-semibold">Configuration: {configuration}</h2>
          <h2 className="md:text-lg font-semibold">Area: {area || "N/A"}</h2>
          <h1 className="font-bold text-xl">Price: ₹ {price || "N/A"}</h1>
        </div>

        {/* 🏠 Property Features */}
        <div>
          <h2 className="font-semibold">Amenities:</h2>
          <ul className="flex items-center w-full text-sm gap-4 flex-wrap">
            {features.length > 0 ? (
              features.map((feature, index) => (
                <li key={index} className="flex-center gap-1">
                  <Check size={15} />
                  <p className="text-gray-700">{feature}</p>
                </li>
              ))
            ) : (
              <p className="text-gray-700">No features listed.</p>
            )}
          </ul>
        </div>

        {/* 📍 Location & Other Info */}
        <div className="flex justify-between items-center w-full">
          <div className="flex flex-wrap gap-4 items-center text-lg">
            <div className="flex items-center gap-2">
              <h2 className="font-semibold">Location: {location || "Not specified"}</h2> |
              <span className="text-xs font-semibold mt-1">
                {address.city},&nbsp;{address.state}
              </span>
            </div>
          </div>
          <p className="text-xs font-semibold text-grey-1">
            Last Updated: <span>{moment(updatedAt).fromNow()}</span>
          </p>
        </div>

        <hr className="w-full max-w-full my-4" />

        {/* 📝 Property Description */}
        <div>
          <h1 className="text-xl font-semibold">About</h1>
          <p className="text-grey-1 leading-relaxed">{description || "No description available."}</p>
        </div>

        {/* 📨 Contact Form */}
        <div className="mt-8 w-full flex justify-center">
          <DialogBox />
        </div>
      </div>

      {/* 🏘️ Recommended Properties (Slider) */}
      {recommended.length > 0 && (
        <>
          <hr className="my-8 w-full max-w-4xl" />
          <div className="w-full max-w-6xl">
            <h1 className="text-2xl font-semibold mb-4 text-home">Recommended Properties</h1>
            <DynamicCarousel data={recommended as Property[]} loading={false} type="home-properties" />
            </div>
        </>
      )}
    </section>
  );
};

export default PropertyDetails;
